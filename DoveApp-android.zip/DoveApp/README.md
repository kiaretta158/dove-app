# DOV'È — app Android nativa per traslochi

Progetto Kotlin + Jetpack Compose, pronto da aprire in **Android Studio** (versione consigliata: Ladybug o più recente).

## Cosa fa
- **Centro di comando**: dashboard con statistiche (scatole totali, arrivate, stanze coinvolte).
- **Nuova scatola**: foto in-app con CameraX, dettatura vocale del contenuto (SpeechRecognizer di sistema, in italiano), scelta della stanza/destinazione, flag "fragile".
- **Etichetta QR**: generata offline (libreria ZXing) per ogni scatola, subito dopo il salvataggio.
- **Scansiona per ritrovare**: fotocamera live con lettura QR offline (ML Kit, modello a bordo — nessuna connessione richiesta), più un'alternativa "scegli dalla galleria" per quando la foto del QR è già stata scattata.
- **Tutto offline**: i dati vivono in un database locale (Room), le foto restano nello storage privato dell'app. Nessuna sincronizzazione cloud, nessun permesso di archiviazione esterno necessario.

## Come aprirlo
1. Scompatta la cartella `DoveApp`.
2. Apri Android Studio → **Open** → seleziona la cartella `DoveApp`.
3. Al primo avvio Android Studio scarica automaticamente il **Gradle wrapper** mancante (serve una connessione internet una tantum: il file `gradle-wrapper.jar` non è incluso in questo pacchetto perché è binario). Se richiesto, clicca "Sync Now" / "Trust Project".
4. Collega un telefono Android reale (min. Android 8.0 / API 26) via USB con il debug USB attivo, oppure usa un emulatore **con supporto fotocamera e microfono virtuali abilitati** nelle impostazioni dell'AVD.
5. Premi ▶ Run.

Al primo utilizzo l'app chiederà i permessi di **fotocamera** e **microfono**: sono necessari rispettivamente per fotografare le scatole/scansionare i QR e per la dettatura vocale.

## Struttura del progetto
```
DoveApp/
  app/
    src/main/java/com/dove/trasloco/
      data/          → entità Room, DAO, database, repository, elenco stanze
      ui/theme/       → palette colori e tipografia
      ui/components/  → card riutilizzabile per la lista scatole
      ui/screens/     → Home, Nuova scatola, Scansiona, Dettaglio
      ui/navigation/  → grafo di navigazione (Navigation Compose)
      util/           → generazione QR (QrUtil), dettatura vocale (VoiceDictationHelper), storage foto
      MainActivity.kt
      DoveApplication.kt
```

## Personalizzazioni facili
- **Font**: `ui/theme/Type.kt` usa i font di sistema (Roboto) con pesi marcati per richiamare lo stile "etichetta da magazzino". Per usare font reali come Bebas Neue o IBM Plex, aggiungi i file `.ttf` in `res/font` e aggiorna `FontFamily` in quel file.
- **Stanze/destinazioni**: modifica l'elenco in `data/Rooms.kt` per aggiungere o rinominare le categorie (es. "Balcone", "Studio", ecc.).
- **Formato del codice scatola**: la logica è in `data/BoxRepository.kt` (funzione `nextCode`).

## Nota sulle versioni
Il progetto usa AGP 8.9.1, Kotlin 2.2.20, Gradle 8.11.1 e le versioni più recenti di Room/CameraX/ML Kit disponibili al momento della creazione. Se Android Studio suggerisce aggiornamenti automatici delle dipendenze al primo sync, puoi accettarli tranquillamente.
