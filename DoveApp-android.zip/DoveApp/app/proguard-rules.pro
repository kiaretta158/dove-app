# Regole ProGuard/R8. Il minify è disattivato di default in questo progetto,
# ma il file è qui pronto per quando vorrai abilitarlo in release.
