package com.dove.trasloco.data

import androidx.compose.ui.graphics.Color

data class RoomOption(val key: String, val label: String, val color: Color)

val ROOM_OPTIONS = listOf(
    RoomOption("cantina", "Cantina", Color(0xFF6B4F3A)),
    RoomOption("garage", "Garage", Color(0xFF5C6B73)),
    RoomOption("deposito", "Deposito", Color(0xFF4F6F52)),
    RoomOption("cucina", "Cucina", Color(0xFFB5741E)),
    RoomOption("salotto", "Salotto", Color(0xFFAF3B34)),
    RoomOption("camera", "Camera", Color(0xFF7A5C8E)),
    RoomOption("ufficio", "Ufficio", Color(0xFF2E5E8C)),
    RoomOption("altro", "Altro", Color(0xFF8A8578))
)

fun roomOptionFor(key: String): RoomOption =
    ROOM_OPTIONS.find { it.key == key } ?: ROOM_OPTIONS.last()
