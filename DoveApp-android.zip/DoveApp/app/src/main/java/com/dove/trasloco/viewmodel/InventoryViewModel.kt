package com.dove.trasloco.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dove.trasloco.data.BoxEntity
import com.dove.trasloco.data.BoxRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class BoxUi(
    val id: String,
    val code: String,
    val notes: String,
    val room: String,
    val fragile: Boolean,
    val photoPath: String?,
    val status: String,
    val createdAt: Long
)

private fun BoxEntity.toUi() = BoxUi(id, code, notes, room, fragile, photoPath, status, createdAt)

class InventoryViewModel(private val repository: BoxRepository) : ViewModel() {

    val allBoxes: StateFlow<List<BoxUi>> = repository.observeAll()
        .map { list -> list.map { it.toUi() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchQuery = MutableStateFlow("")
    val activeFilter = MutableStateFlow("tutte")

    val filteredBoxes: StateFlow<List<BoxUi>> =
        combine(allBoxes, searchQuery, activeFilter) { boxes, query, filter ->
            boxes.filter { box ->
                val matchesRoom = filter == "tutte" || box.room == filter
                val q = query.trim().lowercase()
                val matchesQuery = q.isEmpty() ||
                    box.notes.lowercase().contains(q) ||
                    box.code.lowercase().contains(q) ||
                    box.room.lowercase().contains(q)
                matchesRoom && matchesQuery
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(value: String) { searchQuery.value = value }
    fun setFilter(value: String) { activeFilter.value = value }

    fun addBox(notes: String, room: String, fragile: Boolean, photoPath: String?, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val code = repository.nextCode()
            val box = BoxEntity(
                id = UUID.randomUUID().toString(),
                code = code,
                notes = notes,
                room = room,
                fragile = fragile,
                photoPath = photoPath,
                status = "transito",
                createdAt = System.currentTimeMillis()
            )
            repository.addBox(box)
            onDone(box.id)
        }
    }

    fun toggleStatus(box: BoxUi) {
        viewModelScope.launch {
            repository.updateBox(
                BoxEntity(
                    id = box.id, code = box.code, notes = box.notes, room = box.room,
                    fragile = box.fragile, photoPath = box.photoPath,
                    status = if (box.status == "arrivata") "transito" else "arrivata",
                    createdAt = box.createdAt
                )
            )
        }
    }

    fun deleteBox(box: BoxUi) {
        viewModelScope.launch { repository.deleteBox(
            BoxEntity(box.id, box.code, box.notes, box.room, box.fragile, box.photoPath, box.status, box.createdAt)
        ) }
    }

    fun clearAll() {
        viewModelScope.launch { repository.clearAll() }
    }

    /** Usato dalla schermata di scansione: cerca una scatola per codice QR. */
    suspend fun findByCode(code: String): BoxUi? = repository.findByCode(code)?.toUi()
}

class InventoryViewModelFactory(private val repository: BoxRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return InventoryViewModel(repository) as T
    }
}
