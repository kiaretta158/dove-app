package com.dove.trasloco.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.dove.trasloco.data.roomOptionFor
import com.dove.trasloco.ui.theme.*
import com.dove.trasloco.util.QrUtil
import com.dove.trasloco.viewmodel.BoxUi
import com.dove.trasloco.viewmodel.InventoryViewModel
import java.io.File

@Composable
fun DetailScreen(viewModel: InventoryViewModel, navController: NavController, boxId: String) {
    val allBoxes by viewModel.allBoxes.collectAsState()
    val box = allBoxes.find { it.id == boxId }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = { Text(box?.code ?: "Scatola", fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Indietro")
                    }
                },
                actions = {
                    if (box != null) {
                        IconButton(onClick = { showDeleteConfirm = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Elimina", tint = Stamp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PanelDark, titleContentColor = Paper, navigationIconContentColor = Paper)
            )
        }
    ) { padding ->
        if (box == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Scatola non trovata.", color = PaperDim)
            }
            return@Scaffold
        }

        val room = roomOptionFor(box.room)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(18.dp)
        ) {
            if (box.photoPath != null) {
                AsyncImage(
                    model = File(box.photoPath),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(4f / 3f)
                        .clip(RoundedCornerShape(14.dp))
                        .border(2.dp, Ink, RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.height(14.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(box.code, color = Paper, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(room.color)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(room.label.uppercase(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (box.fragile) {
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .border(1.5.dp, Stamp, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text("FRAGILE / PRIORITARIA", color = Stamp, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(Modifier.height(14.dp))
            Text(
                box.notes.ifBlank { "Nessuna descrizione" },
                color = PaperDim, fontSize = 14.5.sp
            )

            Spacer(Modifier.height(20.dp))
            QrDisplay(box.code)
            Text(
                "Stampa o mostra questo QR: scansionalo per riaprire la scheda in un istante.",
                color = Slate, fontSize = 11.5.sp, modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { viewModel.toggleStatus(box) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = if (box.status == "arrivata")
                    ButtonDefaults.buttonColors(containerColor = PanelDark, contentColor = Paper)
                else
                    ButtonDefaults.buttonColors(containerColor = Tape, contentColor = Color.White)
            ) {
                Text(if (box.status == "arrivata") "Segna come \"in transito\"" else "Segna come arrivata a destinazione", fontWeight = FontWeight.Bold)
            }
        }

        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Eliminare questa scatola?") },
                text = { Text("L'etichetta e la foto associata verranno rimosse dall'inventario.") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteBox(box)
                        showDeleteConfirm = false
                        navController.popBackStack()
                    }) { Text("Elimina", color = Stamp) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) { Text("Annulla") }
                }
            )
        }
    }
}

@Composable
private fun QrDisplay(code: String) {
    val bitmap = remember(code) { QrUtil.generateQrBitmap(code, sizePx = 480) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .border(1.5.dp, Ink, RoundedCornerShape(10.dp))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "QR della scatola $code",
            modifier = Modifier.size(200.dp)
        )
    }
}
