package com.dove.trasloco.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.dove.trasloco.data.ROOM_OPTIONS
import com.dove.trasloco.ui.theme.*
import com.dove.trasloco.util.PhotoStore
import com.dove.trasloco.util.VoiceDictationHelper
import com.dove.trasloco.viewmodel.InventoryViewModel
import java.io.File

@Composable
fun AddBoxScreen(viewModel: InventoryViewModel, navController: NavController) {
    val context = LocalContext.current
    var notes by remember { mutableStateOf("") }
    var selectedRoom by remember { mutableStateOf(ROOM_OPTIONS.first().key) }
    var fragile by remember { mutableStateOf(false) }
    var photoFile by remember { mutableStateOf<File?>(null) }
    var showCamera by remember { mutableStateOf(false) }

    var isListening by remember { mutableStateOf(false) }
    var dictationHint by remember { mutableStateOf("Tocca il microfono e parla: il testo si aggiunge da solo.") }
    val baseTextRef = remember { mutableStateOf("") }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            baseTextRef.value = notes
            startDictation(context, baseTextRef.value, onPartial = { notes = it }, onFinal = { notes = it },
                onError = { dictationHint = it }, onListeningChange = { isListening = it })
        } else {
            dictationHint = "Serve il permesso microfono per la dettatura vocale."
        }
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = { Text("Nuova scatola", fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Indietro")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PanelDark, titleContentColor = Paper, navigationIconContentColor = Paper)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Text("Fotografa, detta il contenuto a voce, scegli la stanza. Genero io l'etichetta con QR.", color = PaperDim, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))

            SectionLabel("Foto della scatola")
            if (showCamera) {
                CameraCaptureView(
                    onCaptured = { file -> photoFile = file; showCamera = false },
                    onCancel = { showCamera = false }
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Paper)
                            .border(2.dp, Ink, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (photoFile != null) {
                            AsyncImage(model = photoFile, contentDescription = null, modifier = Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Filled.AddAPhoto, contentDescription = null, tint = Slate)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    OutlinedButton(onClick = { showCamera = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Paper)) {
                        Text(if (photoFile != null) "Rifai la foto" else "Scatta foto")
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionLabel("Contenuto (detta a voce o scrivi)")
            Row(verticalAlignment = Alignment.Top) {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.weight(1f),
                    minLines = 3,
                    placeholder = { Text("Es. Libri di cucina, tovaglie, pentole in acciaio…") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                        focusedBorderColor = Ink, unfocusedBorderColor = Ink.copy(alpha = 0.4f)
                    )
                )
                Spacer(Modifier.width(10.dp))
                FilledIconButton(
                    onClick = {
                        if (isListening) {
                            isListening = false
                        } else {
                            val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (hasPermission) {
                                baseTextRef.value = notes
                                startDictation(context, baseTextRef.value, onPartial = { notes = it }, onFinal = { notes = it },
                                    onError = { dictationHint = it }, onListeningChange = { isListening = it })
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Stamp, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = "Dettatura vocale")
                }
            }
            Text(dictationHint, color = Slate, fontSize = 11.5.sp, modifier = Modifier.padding(top = 6.dp))

            Spacer(Modifier.height(20.dp))
            SectionLabel("Destinazione")
            RoomPickerGrid(selected = selectedRoom, onSelect = { selectedRoom = it })

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = fragile, onCheckedChange = { fragile = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Stamp))
                Spacer(Modifier.width(10.dp))
                Text("Contenuto fragile / prioritario", color = Paper, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(28.dp))
            Button(
                onClick = {
                    viewModel.addBox(notes, selectedRoom, fragile, photoFile?.absolutePath) { id ->
                        navController.navigate("detail/$id") {
                            popUpTo("home")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Tape, contentColor = Color.White)
            ) {
                Text("Genera etichetta e QR", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

private fun startDictation(
    context: android.content.Context,
    baseText: String,
    onPartial: (String) -> Unit,
    onFinal: (String) -> Unit,
    onError: (String) -> Unit,
    onListeningChange: (Boolean) -> Unit
) {
    val prefix = if (baseText.isBlank()) "" else "$baseText "
    val helper = VoiceDictationHelper(
        context = context,
        onPartialText = { onPartial((prefix + it).trim()) },
        onFinalText = { onFinal((prefix + it).trim()) },
        onError = onError,
        onListeningChange = onListeningChange
    )
    helper.start()
}

@Composable
private fun SectionLabel(text: String) {
    Text(text.uppercase(), color = Slate, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RoomPickerGrid(selected: String, onSelect: (String) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ROOM_OPTIONS.forEach { room ->
            val isSelected = room.key == selected
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) room.color else Color.White)
                    .border(1.5.dp, if (isSelected) room.color else LineDim, RoundedCornerShape(8.dp))
                    .clickableSimple { onSelect(room.key) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(room.label, color = if (isSelected) Color.White else Ink, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun Modifier.clickableSimple(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = onClick
)

@Composable
private fun CameraCaptureView(onCaptured: (File) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasPermission = granted }

    LaunchedEffect(Unit) { if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA) }

    if (!hasPermission) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Serve il permesso fotocamera per scattare la foto.", color = PaperDim)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Consenti fotocamera") }
        }
        return
    }

    val imageCapture = remember { ImageCapture.Builder().build() }

    Column {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
                .clip(RoundedCornerShape(12.dp)),
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture
                        )
                    } catch (_: Exception) { }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            }
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    val file = PhotoStore.createPhotoFile(context)
                    val options = ImageCapture.OutputFileOptions.Builder(file).build()
                    imageCapture.takePicture(
                        options,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                onCaptured(file)
                            }
                            override fun onError(exception: ImageCaptureException) {
                                onCancel()
                            }
                        }
                    )
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Tape, contentColor = Color.White)
            ) { Text("Scatta") }
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Annulla") }
        }
    }
}
