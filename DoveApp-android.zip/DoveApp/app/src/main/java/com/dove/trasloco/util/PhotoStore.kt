package com.dove.trasloco.util

import android.content.Context
import java.io.File

/**
 * Le foto restano nello storage privato dell'app (filesDir), quindi non
 * servono permessi di archiviazione e i dati sopravvivono offline tra un
 * riavvio e l'altro dell'app.
 */
object PhotoStore {

    fun createPhotoFile(context: Context): File {
        val dir = File(context.filesDir, "photos").apply { if (!exists()) mkdirs() }
        val name = "box_${System.currentTimeMillis()}.jpg"
        return File(dir, name)
    }
}
