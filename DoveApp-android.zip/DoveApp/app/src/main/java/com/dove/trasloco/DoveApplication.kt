package com.dove.trasloco

import android.app.Application
import com.dove.trasloco.data.AppDatabase
import com.dove.trasloco.data.BoxRepository

class DoveApplication : Application() {

    lateinit var repository: BoxRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getInstance(this)
        repository = BoxRepository(database.boxDao())
    }
}
