package com.dove.trasloco.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.dove.trasloco.data.roomOptionFor
import com.dove.trasloco.ui.theme.Ink
import com.dove.trasloco.ui.theme.Paper
import com.dove.trasloco.ui.theme.PaperDim
import com.dove.trasloco.ui.theme.Stamp
import com.dove.trasloco.ui.theme.Tape
import com.dove.trasloco.viewmodel.BoxUi
import java.io.File

@Composable
fun TagCard(box: BoxUi, onClick: () -> Unit) {
    val room = roomOptionFor(box.room)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Paper)
            .border(1.dp, Color.Black.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
            .clickableNoRipple(onClick)
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(PaperDim)
                .border(2.dp, Ink, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (box.photoPath != null) {
                AsyncImage(
                    model = File(box.photoPath),
                    contentDescription = "Foto scatola ${box.code}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Filled.Inventory2, contentDescription = null, tint = PaperDim.copy(alpha = 0.9f))
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(box.code, color = Color(0xFF5C6B73), fontWeight = FontWeight.SemiBold, fontSize = 11.5.sp)
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (box.status == "arrivata") com.dove.trasloco.ui.theme.Crate else Tape)
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = box.notes.ifBlank { "Nessuna descrizione" },
                color = Ink,
                fontSize = 13.sp,
                maxLines = 2
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(room.color)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(room.label.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                if (box.fragile) {
                    Box(
                        modifier = Modifier
                            .border(1.5.dp, Stamp, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                        Text("FRAGILE", color = Stamp, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Piccola estensione per un click senza effetto ripple, per restare fedeli
// all'estetica "etichetta di carta" del prototipo.
@Composable
private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    return this.then(
        Modifier.clickableSimple(onClick)
    )
}

@Composable
private fun Modifier.clickableSimple(onClick: () -> Unit): Modifier {
    return androidx.compose.foundation.clickable(
        interactionSource = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}
