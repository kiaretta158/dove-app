package com.dove.trasloco.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DoveColorScheme = darkColorScheme(
    primary = Tape,
    onPrimary = Ink,
    secondary = Stamp,
    onSecondary = Paper,
    tertiary = Crate,
    background = BgDark,
    onBackground = Paper,
    surface = PanelDark,
    onSurface = Paper,
    surfaceVariant = Paper,
    onSurfaceVariant = Ink,
    outline = LineDim
)

@Composable
fun DoveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DoveColorScheme,
        typography = DoveTypography,
        content = content
    )
}
