package com.dove.trasloco.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BoxDao {

    @Query("SELECT * FROM boxes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BoxEntity>>

    @Query("SELECT * FROM boxes WHERE code = :code LIMIT 1")
    suspend fun findByCode(code: String): BoxEntity?

    @Query("SELECT COUNT(*) FROM boxes")
    suspend fun countAll(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(box: BoxEntity)

    @Update
    suspend fun update(box: BoxEntity)

    @Delete
    suspend fun delete(box: BoxEntity)

    @Query("DELETE FROM boxes")
    suspend fun clearAll()
}
