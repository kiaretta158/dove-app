package com.dove.trasloco

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dove.trasloco.ui.navigation.DoveNavHost
import com.dove.trasloco.ui.theme.DoveTheme
import com.dove.trasloco.viewmodel.InventoryViewModel
import com.dove.trasloco.viewmodel.InventoryViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as DoveApplication
        val factory = InventoryViewModelFactory(app.repository)

        setContent {
            DoveTheme {
                val viewModel: InventoryViewModel = viewModel(factory = factory)
                DoveNavHost(viewModel)
            }
        }
    }
}
