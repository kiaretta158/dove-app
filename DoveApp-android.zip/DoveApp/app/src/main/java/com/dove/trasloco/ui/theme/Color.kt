package com.dove.trasloco.ui.theme

import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF211D1A)
val Paper = Color(0xFFF1E6CE)
val PaperDim = Color(0xFFE4D5B2)
val Tape = Color(0xFFD9932E)
val TapeDark = Color(0xFFB5741E)
val Stamp = Color(0xFFAF3B34)
val Crate = Color(0xFF4F6F52)
val Slate = Color(0xFF5C6B73)
val BgDark = Color(0xFF161311)
val PanelDark = Color(0xFF221E1A)
val LineDim = Color(0xFFC9B98C)
