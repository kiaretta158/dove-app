package com.dove.trasloco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.dove.trasloco.data.ROOM_OPTIONS
import com.dove.trasloco.ui.components.TagCard
import com.dove.trasloco.ui.theme.*
import com.dove.trasloco.viewmodel.InventoryViewModel

@Composable
fun HomeScreen(viewModel: InventoryViewModel, navController: NavController) {
    val boxes by viewModel.filteredBoxes.collectAsState()
    val allBoxes by viewModel.allBoxes.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val filter by viewModel.activeFilter.collectAsState()

    Scaffold(
        containerColor = BgDark,
        bottomBar = { HomeBottomBar(navController) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item { CommandHeader(totale = allBoxes.size, arrivate = allBoxes.count { it.status == "arrivata" }, stanze = allBoxes.map { it.room }.distinct().size) }
            item {
                HeroSearch(
                    query = query,
                    onQueryChange = viewModel::setSearchQuery,
                    onAdd = { navController.navigate("add") },
                    onScan = { navController.navigate("scan") }
                )
            }
            item { RoomChips(active = filter, onSelect = viewModel::setFilter) }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        if (query.isNotBlank()) "Risultati per \u201c$query\u201d" else "Inventario",
                        color = PaperDim, fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                    Text("${boxes.size} elementi", color = PaperDim, fontSize = 11.sp)
                }
            }
            if (boxes.isEmpty()) {
                item { EmptyState(hasAny = allBoxes.isNotEmpty()) }
            } else {
                items(boxes, key = { it.id }) { box ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        TagCard(box = box, onClick = { navController.navigate("detail/${box.id}") })
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun CommandHeader(totale: Int, arrivate: Int, stanze: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelDark)
            .border(width = 2.dp, color = Tape.copy(alpha = 0.6f))
            .padding(20.dp, 22.dp, 20.dp, 16.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Stamp)
                    .border(2.dp, Paper, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) { Text("Q", color = Paper, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(10.dp))
            Text("DOV'È", color = Paper, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Il centro di comando per il trasloco. Fotografa, etichetta, ritrova tutto in pochi secondi.",
            color = PaperDim, fontSize = 12.5.sp
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatChip("Scatole", totale, Modifier.weight(1f))
            StatChip("Arrivate", arrivate, Modifier.weight(1f))
            StatChip("Stanze", stanze, Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatChip(label: String, value: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Paper.copy(alpha = 0.06f))
            .border(1.dp, Paper.copy(alpha = 0.18f), RoundedCornerShape(10.dp))
            .padding(10.dp, 8.dp)
    ) {
        Text(value.toString(), color = Tape, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(label.uppercase(), color = PaperDim, fontSize = 10.sp, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun HeroSearch(query: String, onQueryChange: (String) -> Unit, onAdd: () -> Unit, onScan: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp, 16.dp, 16.dp, 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Paper)
            .padding(16.dp)
    ) {
        Text("TROVA QUALSIASI COSA, ORA", color = Stamp, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Cerca per contenuto, stanza, codice…") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = Ink,
                unfocusedBorderColor = Ink.copy(alpha = 0.4f)
            )
        )
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onAdd,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Tape, contentColor = Color.White)
            ) {
                Icon(Icons.Filled.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Nuova scatola", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onScan,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Paper)
            ) {
                Icon(Icons.Filled.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Scansiona", fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RoomChips(active: String, onSelect: (String) -> Unit) {
    val options = listOf("tutte" to "Tutte") + ROOM_OPTIONS.map { it.key to it.label }
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        items(options) { (key, label) ->
            val isActive = key == active
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (isActive) Tape else Color.Transparent)
                    .border(1.5.dp, if (isActive) Tape else LineDim, RoundedCornerShape(50))
                    .clickable { onSelect(key) }
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            ) {
                Text(label, color = if (isActive) Ink else PaperDim, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun EmptyState(hasAny: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .border(2.dp, LineDim, RoundedCornerShape(14.dp))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (hasAny) "Nessun risultato" else "Ancora nessuna scatola",
            color = Paper, fontSize = 20.sp, fontWeight = FontWeight.Black
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (hasAny) "Prova un'altra parola, oppure cambia stanza qui sopra."
            else "Fotografa la prima scatola, detta il contenuto a voce e genera l'etichetta con QR.",
            color = PaperDim, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun HomeBottomBar(navController: NavController) {
    NavigationBar(containerColor = PanelDark, contentColor = PaperDim) {
        NavigationBarItem(
            selected = true, onClick = {},
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { Text("Casa") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Tape, selectedTextColor = Tape, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = false, onClick = { navController.navigate("scan") },
            icon = { Icon(Icons.Filled.QrCodeScanner, contentDescription = null) },
            label = { Text("Scansiona") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Tape, selectedTextColor = Tape, indicatorColor = Color.Transparent)
        )
        NavigationBarItem(
            selected = false, onClick = { navController.navigate("add") },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            label = { Text("Aggiungi") },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Tape, selectedTextColor = Tape, indicatorColor = Color.Transparent)
        )
    }
}
