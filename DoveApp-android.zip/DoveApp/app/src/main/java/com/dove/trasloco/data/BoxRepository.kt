package com.dove.trasloco.data

import kotlinx.coroutines.flow.Flow

class BoxRepository(private val dao: BoxDao) {

    fun observeAll(): Flow<List<BoxEntity>> = dao.observeAll()

    suspend fun findByCode(code: String): BoxEntity? = dao.findByCode(code)

    suspend fun nextCode(): String {
        val n = dao.countAll() + 1
        return "SC-" + n.toString().padStart(4, '0')
    }

    suspend fun addBox(box: BoxEntity) = dao.insert(box)

    suspend fun updateBox(box: BoxEntity) = dao.update(box)

    suspend fun deleteBox(box: BoxEntity) = dao.delete(box)

    suspend fun clearAll() = dao.clearAll()
}
