package com.dove.trasloco.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dove.trasloco.ui.screens.AddBoxScreen
import com.dove.trasloco.ui.screens.DetailScreen
import com.dove.trasloco.ui.screens.HomeScreen
import com.dove.trasloco.ui.screens.ScanScreen
import com.dove.trasloco.viewmodel.InventoryViewModel

@Composable
fun DoveNavHost(viewModel: InventoryViewModel) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(viewModel, navController) }
        composable("add") { AddBoxScreen(viewModel, navController) }
        composable("scan") { ScanScreen(viewModel, navController) }
        composable(
            route = "detail/{boxId}",
            arguments = listOf(navArgument("boxId") { type = NavType.StringType })
        ) { backStackEntry ->
            val boxId = backStackEntry.arguments?.getString("boxId") ?: return@composable
            DetailScreen(viewModel, navController, boxId)
        }
    }
}
