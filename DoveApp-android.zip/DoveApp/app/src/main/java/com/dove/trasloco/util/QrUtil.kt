package com.dove.trasloco.util

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.common.BitMatrix

/** Genera un QR completamente offline: nessuna chiamata di rete. */
object QrUtil {

    private const val PREFIX = "DOVE:"

    fun contentFor(code: String): String = PREFIX + code

    fun codeFromScannedText(text: String): String = text.removePrefix(PREFIX)

    fun generateQrBitmap(code: String, sizePx: Int = 512): Bitmap {
        val writer = QRCodeWriter()
        val matrix: BitMatrix = writer.encode(contentFor(code), BarcodeFormat.QR_CODE, sizePx, sizePx)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        return bitmap
    }
}
