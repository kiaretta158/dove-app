package com.dove.trasloco.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Una scatola/oggetto dell'inventario di trasloco.
 * Tutto è salvato localmente: l'app funziona anche senza connessione.
 */
@Entity(tableName = "boxes")
data class BoxEntity(
    @PrimaryKey val id: String,
    val code: String,          // es. "SC-0001", stampato anche nel QR
    val notes: String,         // contenuto, scritto o dettato a voce
    val room: String,          // chiave stanza/destinazione, vedi Rooms.kt
    val fragile: Boolean,
    val photoPath: String?,    // percorso file locale della foto, null se assente
    val status: String,        // "transito" oppure "arrivata"
    val createdAt: Long
)
